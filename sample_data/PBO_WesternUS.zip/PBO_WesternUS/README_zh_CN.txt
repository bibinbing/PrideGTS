﻿美国西部95站 GNSS .pos 时间序列数据集（PBO_WesternUS）
============================================
测站数量: 95（station_manifest.csv 逐站列出文件名、产品类型、起止日期和下载地址）
原生文件: 93个 EarthScope/CWU final IGS14 .pos（官方PBO POS 1.1.1格式）
转换文件: 2个（FVPK、UCD1）；EarthScope对应站目录为空，故由UNR IGS20 tenv3转换为PBO 1.1.0兼容字段结构
转换文件名含 ngl.igs20.converted，且在station_manifest.csv中明确标记，未冒充PBO原生产品
95站文件跨度的共同交集: 2000-09-28 至 2025-11-26
公共10年统计窗口: 2015-01-01 至 2024-12-31
95站均有记录的精确公共日历历元（窗口内）: 1035（逐日列于common_epochs.txt）
精确公共历元首日/末日: 2015-01-15 / 2024-12-24
注意: PBO IGS14 与 NGL IGS20 属于不同机构解和参考框架实现，不应把两类坐标数值视为同一解。
